function start_text(){
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(25);
  text("Click anywhere to start", width/2, height*3/4)
}

function next_text(){
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(25);
  text("Click when player 2 is ready", width/2, height*3/4)
}

function reset_text(){
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(25);
  text("Click to restart game", width/2, height*3/4)
  if (player1 < player2){
    text("The winner is player 1", width/2, height/4)
  } else if (player2 < player1){
    text("The winner is player 2", width/2, height/4)
  } else {
    text("The match is draw", width/2, height/4)
  }
}


function timer_text(){
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(50);
  text(timer.toFixed(3)+" s", width/2, height/2)
}

function shoot_text(){
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(25);
  text("SHOOT!", width/2, height/4)
}

function disqualify_text(){
  fill(255, 0, 0);
  textAlign(CENTER, CENTER);
  textSize(25);
  text("Too early, disqualified!", width/2, height/2)
}

function player1_turn(){
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(25);
  text("Player 1's turn", width/2, height/4)
}

function player2_turn(){
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(25);
  text("Player 2's turn", width/2, height/4)
}

function player_stat(){
  fill(255);
  textAlign(LEFT, CENTER);
  textSize(15);
  text("Player 1: "+player1.toFixed(3)+" s", 15, height-40)
  text("Player 2: "+player2.toFixed(3)+" s", 15, height-25)
}